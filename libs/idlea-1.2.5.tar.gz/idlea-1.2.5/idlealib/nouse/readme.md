# Stop extensions
Move script file(s) to this folder to stop using extension.
