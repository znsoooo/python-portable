import webbrowser

webbrowser.open("https://github.com/znsoooo/IDLE-Advance")
